# Changelog

## Version 1.2.0
  * Swift 2.2 support
  * Support for animation completion blocks

## Version 1.1.1
  * Fixes bug #57 in Yoshiko

## Version 1.1.0
  * Support to change the placeholder font via the `placeholderFontScale` property.
  * Fixed some minor issues with the example project.

## Version 1.0.0
  * Initial release with 9 different UITextField effects.
  * Full Interface Builder support.
  * Full code only support.
  * Cocoapods support.
  * Carthage support.
